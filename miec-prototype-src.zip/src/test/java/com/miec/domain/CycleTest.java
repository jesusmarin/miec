package com.miec.domain;

import com.miec.state.CycleState;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class CycleTest {

    private Cycle cycle;

    @BeforeEach
    void setUp() {
        cycle = new Cycle(
                "Experimento MIEC-001",
                "Validar la corrección controlada de defectos"
        );
    }

    @Test
    @DisplayName("Debe crear un ciclo en estado INACTIVO")
    void shouldCreateCycleInInactiveState() {

        assertThat(cycle.getId()).isNotNull()
                .isInstanceOf(UUID.class);

        assertThat(cycle.getName())
                .isEqualTo("Experimento MIEC-001");

        assertThat(cycle.getObjective())
                .isEqualTo("Validar la corrección controlada de defectos");

        assertThat(cycle.getStatus())
                .isEqualTo(CycleState.E00_INACTIVO);

        assertThat(cycle.getCreatedAt()).isNotNull();
        assertThat(cycle.getStartedAt()).isNull();
        assertThat(cycle.getFinishedAt()).isNull();
    }

    @Test
    @DisplayName("No debe permitir crear un ciclo sin nombre")
    void shouldRejectEmptyName() {

        assertThatThrownBy(() ->
                new Cycle(" ", "Objetivo de prueba")
        )
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("El nombre es obligatorio");
    }

    @Test
    @DisplayName("No debe permitir crear un ciclo sin objetivo")
    void shouldRejectEmptyObjective() {

        assertThatThrownBy(() ->
                new Cycle("Ciclo de prueba", " ")
        )
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("El objetivo es obligatorio");
    }

    @Test
    @DisplayName("Debe iniciar correctamente el ciclo")
    void shouldStartCycle() {

        cycle.start();

        assertThat(cycle.getStatus())
                .isEqualTo(CycleState.E01_INICIALIZANDO);

        assertThat(cycle.getStartedAt()).isNull();
    }

    @Test
    @DisplayName("Debe registrar la fecha cuando comienza la ejecución")
    void shouldRegisterStartTimeWhenExecutionBegins() {

        cycle.start();
        cycle.transitionTo(CycleState.E02_OBSERVANDO);
        cycle.transitionTo(CycleState.E03_DIAGNOSTICANDO);
        cycle.transitionTo(CycleState.E04_PLANIFICANDO);
        cycle.transitionTo(CycleState.E05_ESPERANDO_AUTORIZACION);
        cycle.transitionTo(CycleState.E06_PREPARADO);
        cycle.transitionTo(CycleState.E07_EJECUTANDO);

        assertThat(cycle.getStatus())
                .isEqualTo(CycleState.E07_EJECUTANDO);

        assertThat(cycle.getStartedAt()).isNotNull();
        assertThat(cycle.getFinishedAt()).isNull();
    }

    @Test
    @DisplayName("Debe rechazar una transición no permitida")
    void shouldRejectInvalidTransition() {

        assertThatThrownBy(() ->
                cycle.transitionTo(CycleState.E07_EJECUTANDO)
        )
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("Transición no permitida");

        assertThat(cycle.getStatus())
                .isEqualTo(CycleState.E00_INACTIVO);
    }

    @Test
    @DisplayName("Debe suspender un ciclo en ejecución")
    void shouldSuspendCycle() {

        moveCycleToExecution();

        cycle.suspend();

        assertThat(cycle.getStatus())
                .isEqualTo(CycleState.E12_SUSPENDIDO);

        assertThat(cycle.isSuspended()).isTrue();
    }

    @Test
    @DisplayName("Debe recuperar un ciclo suspendido")
    void shouldResumeSuspendedCycle() {

        moveCycleToExecution();

        cycle.suspend();
        cycle.resume();

        assertThat(cycle.getStatus())
                .isEqualTo(CycleState.E13_RECUPERANDO);
    }

    @Test
    @DisplayName("No debe permitir recuperar un ciclo no suspendido")
    void shouldRejectResumeWhenNotSuspended() {

        assertThatThrownBy(cycle::resume)
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("Solo se puede reanudar");
    }

    @Test
    @DisplayName("Debe finalizar correctamente el ciclo")
    void shouldFinishCycle() {

        cycle.start();
        cycle.transitionTo(CycleState.E02_OBSERVANDO);
        cycle.transitionTo(CycleState.E03_DIAGNOSTICANDO);
        cycle.transitionTo(CycleState.E04_PLANIFICANDO);
        cycle.transitionTo(CycleState.E05_ESPERANDO_AUTORIZACION);
        cycle.transitionTo(CycleState.E06_PREPARADO);
        cycle.transitionTo(CycleState.E07_EJECUTANDO);
        cycle.transitionTo(CycleState.E08_VERIFICANDO);
        cycle.transitionTo(CycleState.E09_DECIDIENDO);

        Instant beforeFinish = Instant.now();

        cycle.finish();

        assertThat(cycle.getStatus())
                .isEqualTo(CycleState.E14_FINALIZADO);

        assertThat(cycle.isTerminal()).isTrue();
        assertThat(cycle.getFinishedAt()).isNotNull();
        assertThat(cycle.getFinishedAt()).isAfterOrEqualTo(beforeFinish);
    }

    @Test
    @DisplayName("No debe permitir modificar un ciclo finalizado")
    void shouldRejectChangesAfterFinishing() {

        cycle.start();
        cycle.transitionTo(CycleState.E02_OBSERVANDO);
        cycle.transitionTo(CycleState.E03_DIAGNOSTICANDO);
        cycle.transitionTo(CycleState.E04_PLANIFICANDO);
        cycle.transitionTo(CycleState.E05_ESPERANDO_AUTORIZACION);
        cycle.transitionTo(CycleState.E06_PREPARADO);
        cycle.transitionTo(CycleState.E07_EJECUTANDO);
        cycle.transitionTo(CycleState.E08_VERIFICANDO);
        cycle.transitionTo(CycleState.E09_DECIDIENDO);

        cycle.finish();

        assertThatThrownBy(() ->
                cycle.transitionTo(CycleState.E02_OBSERVANDO)
        )
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("ciclo terminado");
    }

    @Test
    @DisplayName("Debe abortar correctamente el ciclo")
    void shouldAbortCycle() {

        cycle.start();
        cycle.abort();

        assertThat(cycle.getStatus())
                .isEqualTo(CycleState.E15_ABORTADO);

        assertThat(cycle.isTerminal()).isTrue();
        assertThat(cycle.getFinishedAt()).isNotNull();
    }

    @Test
    @DisplayName("No debe permitir finalizar directamente un ciclo inactivo")
    void shouldRejectFinishingInactiveCycle() {

        assertThatThrownBy(cycle::finish)
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("Transición no permitida");
    }

    private void moveCycleToExecution() {

        cycle.start();
        cycle.transitionTo(CycleState.E02_OBSERVANDO);
        cycle.transitionTo(CycleState.E03_DIAGNOSTICANDO);
        cycle.transitionTo(CycleState.E04_PLANIFICANDO);
        cycle.transitionTo(CycleState.E05_ESPERANDO_AUTORIZACION);
        cycle.transitionTo(CycleState.E06_PREPARADO);
        cycle.transitionTo(CycleState.E07_EJECUTANDO);
    }
}
